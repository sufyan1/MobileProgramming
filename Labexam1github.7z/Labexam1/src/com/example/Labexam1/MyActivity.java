package com.example.Labexam1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MyActivity extends Activity {
    EditText txtValue1;
    EditText txtValue2;
    EditText txtValue3;
    EditText txtValue4;
    EditText txtValue5;
    TextView txtResult;
    TextView maxresult;
    TextView minresult;
    Button btnAdd;
    Button btnact3;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main1);
        txtValue1 = (EditText) findViewById(R.id.EditText01);
        txtValue2 = (EditText) findViewById(R.id.EditText02);
        txtValue3 = (EditText) findViewById(R.id.EditText03);
        txtValue4 = (EditText) findViewById(R.id.EditText04);
        txtValue5 = (EditText) findViewById(R.id.EditText05);

        txtResult = (TextView) findViewById(R.id.txtResult);
        maxresult = (TextView) findViewById(R.id.max);
        minresult = (TextView) findViewById(R.id.min);
        btnact3= (Button) findViewById(R.id.act3);
        btnAdd = (Button) findViewById(R.id.btnAdd);

        btnAdd.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // get values from the UI
                int v1 = 1;
                int v2 = 2;
                int v3 = 3;
                int v4 = 4;
                int v5 = 5;

                Intent myIntentA1A2 = new Intent(MyActivity.this,
                        Activity2.class);
                // create a Bundle (MAP) container to ship data
                Bundle myDataBundle = new Bundle();

                // add <key,value> data items to the container
                myDataBundle.putInt("val1", v1);
                myDataBundle.putInt("val2", v2);
                myDataBundle.putInt("val3", v3);
                myDataBundle.putInt("val4", v4);
                myDataBundle.putInt("val5", v5);
               // myDataBundle.putDouble("val2", v2);

                // attach the container to the intent
                myIntentA1A2.putExtras(myDataBundle);

                // call Activity2, tell your local listener to wait a
                // response sent to a listener known as 101
                startActivityForResult(myIntentA1A2, 101);

            }

        });
        btnact3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // get values from the UI
                Double v1 = Double.parseDouble(txtValue1.getText().toString());
                Double v2 = Double.parseDouble(txtValue2.getText().toString());
                Double v3 = Double.parseDouble(txtValue3.getText().toString());
                Double v4 = Double.parseDouble(txtValue4.getText().toString());
                Double v5 = Double.parseDouble(txtValue5.getText().toString());


                // create intent to call Activity3
                Intent mynewIntentA1A2 = new Intent (MyActivity.this,
                        Activity3.class);
                // create a Bundle (MAP) container to ship data
                Bundle mynewDataBundle = new Bundle();

                // add <key,value> data items to the container
                mynewDataBundle.putDouble("val1", v1);
                mynewDataBundle.putDouble("val2", v2);
                mynewDataBundle.putDouble("val1", v3);
                mynewDataBundle.putDouble("val2", v4);
                mynewDataBundle.putDouble("val1", v5);



                // attach the container to the intent
                mynewIntentA1A2.putExtras(mynewDataBundle);

                // call Activity2, tell your local listener to wait a
                // response sent to a listener known as 101
                startActivityForResult(mynewIntentA1A2, 102);

            }
        });
    }//onCreate
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try	{
            if ((requestCode == 101 ) && (resultCode == Activity.RESULT_OK)){
                Bundle myResultBundle = data.getExtras();
                int myResult = myResultBundle.getInt("vresult");
                int max = myResultBundle.getInt("max value");
                int min = myResultBundle.getInt("min value");
                txtResult.setText("Sum is " + myResult);
                maxresult.setText("max value is  " + max);
                minresult.setText("min value is " + min);

            }
            else if((requestCode == 102 ) && (resultCode == Activity.RESULT_OK)){
                Bundle myResultBundle = data.getExtras();
                int myResult = myResultBundle.getInt("vresult");
                int max = myResultBundle.getInt("max value");
                int min = myResultBundle.getInt("min value");
                txtResult.setText("Sum is " + myResult);
                maxresult.setText("max value is  " + max);
                minresult.setText("min value is " + min);

            }
        }
        catch (Exception e) {
            txtResult.setText("Problems - " + requestCode + " " + resultCode);
        }
    }//onActivityResult


}//Activity1
