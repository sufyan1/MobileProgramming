package com.example.Labexam1;

/**
 * Created by g00282413 on 22/10/2015.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Activity2 extends Activity implements OnClickListener{
    EditText dataReceived;
    Button  btnDone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        dataReceived = (EditText) findViewById(R.id.etDataReceived);
        btnDone = (Button) findViewById(R.id.btnDone);
        btnDone.setOnClickListener(this);

        // pick call made to Activity2 via Intent
        Intent myLocalIntent = getIntent();

        // look into the bundle sent to Activity2 for data items
        Bundle myBundle =  myLocalIntent.getExtras();
        int v1 = myBundle.getInt("val1");
        int v2 = myBundle.getInt("val2");
        int v3 = myBundle.getInt("val3");
        int v4 = myBundle.getInt("val4");
        int v5 = myBundle.getInt("val5");
        //Double v2 = myBundle.getDouble("val2");

        // operate on the input data
        int vResult =  v1 + v2 +v3+v4+v5;
        int max=v1;
        int min=v5;
        // if v1 is max
        //for max condition
        if(v1 > v2 && v1 > v3 && v1>v4 && v1>v5){
            max=v1;
        }
        //v2
        if(v2 > v1 && v2 > v3 && v2>v4 && v2>v5){
            max=v2;
        }
        //if v3 is max
        if(v3 > v2 && v3 > v1 && v3>v4 && v3>v5){
            max=v3;
        }
        //v4
        if(v4 > v2 && v4 > v3 && v4>v1 && v4>v5){
            max=v4;
        }
        //v5
        if(v5 > v2 && v5 > v3 && v5>v4 && v5>v1){
            max=v5;
        }

        //for min value
        //////////////////////////////////////////////////
        /////////////////////////////////////////////////
        if(v1 < v2 && v1 < v3 && v1<v4 && v1<v5){
            min=v1;
        }
        //v2
        if(v2 < v1 && v2 < v3 && v2<v4 && v2<v5){
            min=v2;
        }
        //if v3 is max
        if(v3 < v2 && v3 < v1 && v3<v4 && v3<v5){
            min=v3;
        }
        //v4
        if(v4 < v2 && v4 < v3 && v4<v1 && v4<v5){
            min=v4;
        }
        //v5
        if(v5 < v2 && v5 < v3 && v5<v4 && v5<v1){
            min=v5;
        }

        // for illustration purposes. show data received & result
        dataReceived.setText("Data received is \n"
                + "val1= " + v1 + "\nval2= " + v2 +"\nval3= " +v3 +"\nval4= "+ v4 +"\nval5= "+v5);
               // + "\n\nsum= " + vResult + "\nmax num is= " +max +"\nmin num is= " +min);

        // add to the bundle the computed result

        myBundle.putInt("vresult", vResult);
        myBundle.putInt("max value", max);
        myBundle.putInt("min value", min);
        // attach updated bumble to invoking intent
        myLocalIntent.putExtras(myBundle);

        // return sending an OK signal to calling activity
        setResult(Activity.RESULT_OK, myLocalIntent);

        // experiment: remove comment
        // finish();

    }//onCreate

    @Override
    public void onClick(View v) {
        // close current screen - terminate Activity2
        finish();
    }

}
