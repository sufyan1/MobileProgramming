package com.example.Labexam1;

/**
 * Created by g00282413 on 22/10/2015.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Activity3 extends Activity implements OnClickListener{

    EditText dataReceived;
    Button  btngetvalue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main3);
        dataReceived = (EditText) findViewById(R.id.etDataReceive);
        btngetvalue = (Button) findViewById(R.id.btngetval);
        btngetvalue.setOnClickListener(this);

        // pick call made to Activity3 via Intent
        Intent mynewLocalIntent = getIntent();

        // look into the bundle sent to Activity2 for data items
        Bundle mynewBundle =  mynewLocalIntent.getExtras();
        Double v1 = mynewBundle.getDouble("val1");
        Double v2 = mynewBundle.getDouble("val2");
        Double v3 = mynewBundle.getDouble("val1");
        Double v4 = mynewBundle.getDouble("val2");
        Double v5 = mynewBundle.getDouble("val1");



        // operate on the input data
        double vResult =  v1 + v2 +v3+v4+v5;
        double max=v1;
        double min=v5;
        // if v1 is max
        //for max condition
        if(v1 > v2 && v1 > v3 && v1>v4 && v1>v5){
            max=v1;
        }
        //v2
        if(v2 > v1 && v2 > v3 && v2>v4 && v2>v5){
            max=v2;
        }
        //if v3 is max
        if(v3 > v2 && v3 > v1 && v3>v4 && v3>v5){
            max=v3;
        }
        //v4
        if(v4 > v2 && v4 > v3 && v4>v1 && v4>v5){
            max=v4;
        }
        //v5
        if(v5 > v2 && v5 > v3 && v5>v4 && v5>v1){
            max=v5;
        }

        //for min value
        //////////////////////////////////////////////////
        /////////////////////////////////////////////////
        if(v1 < v2 && v1 < v3 && v1<v4 && v1<v5){
            min=v1;
        }
        //v2
        if(v2 < v1 && v2 < v3 && v2<v4 && v2<v5){
            min=v2;
        }
        //if v3 is max
        if(v3 < v2 && v3 < v1 && v3<v4 && v3<v5){
            min=v3;
        }
        //v4
        if(v4 < v2 && v4 < v3 && v4<v1 && v4<v5){
            min=v4;
        }
        //v5
        if(v5 < v2 && v5 < v3 && v5<v4 && v5<v1){
            min=v5;
        }

        // for illustration purposes. show data received & result
        dataReceived.setText("Data received is \n"
                + "val1= " + v1 + "\nval2= " + v2 +"\nval3= " +v3 +"\nval4= "+ v4 +"\nval5= "+v5
         + "\n\nsum= " + vResult + "\nmax num is= " +max +"\nmin num is= " +min);

        // add to the bundle the computed result

        mynewBundle.putDouble("vresult", vResult);
        mynewBundle.putDouble("max value", max);
        mynewBundle.putDouble("min value", min);
        // attach updated bumble to invoking intent
        mynewLocalIntent.putExtras(mynewBundle);

        // return sending an OK signal to calling activity
        setResult(Activity.RESULT_OK, mynewLocalIntent);

        // experiment: remove comment
        // finish();

    }//onCreate
    @Override
    public void onClick(View v) {
        // close current screen - terminate Activity3
        finish();
    }

}
