package com.example.android;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;
import java.util.Random;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MyService extends Service {

  //  MyServiceReceiver myServiceReceiver;

    final static String MY_ACTION = "MY_ACTION";
    final static String MY_ACTION_FROMACTIVITY = "MY_ACTION_FROMACTIVITY";

    public static final String CMD = "CMD";
    public static final int CMD_STOP = 1;
    boolean running;

    String initData;
    int val1;
    int val2;
    int val3;
    String sVal1;
    String sVal2;
    String sVal3;

    Person person;
    int answer1;
    int answer2;
    int answer3;
    int answer4;
    int answer5;



// Generate 10 random integers in the range 0..99.














    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
     //   myServiceReceiver = new MyServiceReceiver();
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // TODO Auto-generated method stub

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(MY_ACTION_FROMACTIVITY);
       // registerReceiver(myServiceReceiver, intentFilter);
        running = true;

       // initData = intent.getStringExtra("INIT_DATA");

     //   int foo = Integer.parseInt("1234");
//        val1 = Integer.parseInt(intent.getStringExtra("VAL1"));
//        val2 = Integer.parseInt(intent.getStringExtra("VAL2"));
//        val3 = Integer.parseInt(intent.getStringExtra("VAL3"));
            sVal1 = intent.getStringExtra("VAL1");
            sVal2 = intent.getStringExtra("VAL2");
        sVal3 = intent.getStringExtra("VAL3");



        //MyThread myThread = new MyThread();
       // myThread.start();
        new HttpAsyncTask().execute("http://10.3.4.81:8080/jsonservlet");

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
       // this.unregisterReceiver(myServiceReceiver);
        super.onDestroy();
    }

//    public class MyThread extends Thread{
//
//        @Override
//        public void run() {
//            // TODO Auto-generated method stub
//            int i = 0;
//            //  while(running){
//            try {
//                Thread.sleep(5000);
//                Intent intent = new Intent();
//                intent.setAction(MY_ACTION);
//
//                intent.putExtra("DATAPASSEDBACK", "testing");
//                intent.putExtra("DATA_BACK", initData);
//
//                sendBroadcast(intent);
//
//                //      i++;
//            } catch (InterruptedException e) {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//            }
//            //   }
//            stopSelf();
//        }
//
//    }

    private class HttpAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {


            person = new Person();
          //  person.setName(etName.getText().toString());
         //  person.setCountry(etCountry.getText().toString());
          //  person.setTwitter(etTwitter.getText().toString());
              person.setName(sVal1);
              person.setCountry(sVal2);
              person.setTwitter(sVal3);

            return POST(urls[0],person);
        }
        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

          //  Toast.makeText(getBaseContext(), "total is : " + result, Toast.LENGTH_LONG).show();
            Intent intent = new Intent();
            Intent intent1 = new Intent();
            intent.setAction(MY_ACTION);
            for(int c=0;c<=1000;c++) {
                Random rn = new Random();
                answer1 = rn.nextInt(10) + 1;
                answer2 = rn.nextInt(10) + 1;
                answer3 = rn.nextInt(10) + 1;
                answer4 = rn.nextInt(10) + 1;
                answer5 = rn.nextInt(10) + 1;

                intent1.putExtra("num1",answer1);
                intent.putExtra("DATAPASSEDBACK", "\nNum1 is: " + answer1 + "\nNum2 is: " + answer2 + "\nNum3 is: " + answer3
                        + "\nNum4 is: " + answer4 + "\nNum5 is: " + answer5);
                intent.putExtra("DATA_BACK", initData);
                sendBroadcast(intent);
             //   sendBroadcast(intent1);
            }
        }
    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }

    public static String POST(String url, Person person){
        InputStream inputStream = null;
        String result = "";
        try {

            // 1. create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // 2. make POST request to the given URL
            HttpPost httpPost = new HttpPost(url);

            String json = "";

            // 3. build jsonObject
            JSONObject jsonObject = new JSONObject();
            jsonObject.accumulate("name", person.getName());
            jsonObject.accumulate("country", person.getCountry());
            jsonObject.accumulate("twitter", person.getTwitter());

            // 4. convert JSONObject to JSON to String
            json = jsonObject.toString();

            // ** Alternative way to convert Person object to JSON string usin Jackson Lib
            // ObjectMapper mapper = new ObjectMapper();
            // json = mapper.writeValueAsString(person);

            // 5. set json to StringEntity
            StringEntity se = new StringEntity(json);

            // 6. set httpPost Entity
            httpPost.setEntity(se);

            // 7. Set some headers to inform server about the type of the content
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            // 8. Execute POST request to the given URL
            HttpResponse httpResponse = httpclient.execute(httpPost);

            // 9. receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();

            // 10. convert inputstream to string
            if(inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        // 11. return result
        return result;
    }

//    public class MyServiceReceiver extends BroadcastReceiver {
//
//        @Override
//        public void onReceive(Context arg0, Intent arg1) {
//            // TODO Auto-generated method stub
//            int hostCmd = arg1.getIntExtra(CMD, 0);
//            if(hostCmd == CMD_STOP){
//                running = false;
//                stopSelf();
//
//                Toast.makeText(MyService.this,
//                        "Service stopped by main Activity!",
//                        Toast.LENGTH_LONG).show();
//            }
//        }
//
//    }

}
