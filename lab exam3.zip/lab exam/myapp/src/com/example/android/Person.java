package com.example.android;

public class Person {

    private String name;
    private String country;
    private String twitter;
    private String v4;

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    private int result;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }
    public String getv4() {
        return v4;
    }

    public void setv4(String v4) {
        this.v4 = v4;
    }
    @Override
    public String toString() {
        return "Person [name=" + name + ", country=" + country + ", twitter="
                + twitter + "]";
    }


}